# vk_schedule_bot
В разработке
